webpackJsonp([70],{897:function(e,t,d){"use strict";function r(e,t,d,r){return o[e]}Object.defineProperty(t,"__esModule",{value:!0}),t.default=r;var o={lastWeek:"[förra] dddd[en kl.] LT",yesterday:"[igår kl.] LT",today:"[idag kl.] LT",tomorrow:"[imorgon kl.] LT",nextWeek:"dddd [kl.] LT",other:"L"};e.exports=t.default}});
//# sourceMappingURL=f1169cac1f8fa01f1661.js.map
