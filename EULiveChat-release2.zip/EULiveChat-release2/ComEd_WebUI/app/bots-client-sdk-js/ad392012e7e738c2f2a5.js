webpackJsonp([153],{819:function(e,d,t){"use strict";function r(e,d,t,r){return o[e]}Object.defineProperty(d,"__esModule",{value:!0}),d.default=r;var o={lastWeek:"[hier] dddd [à] LT",yesterday:"[hier à] LT",today:"[aujourd’hui à] LT",tomorrow:"[demain à] LT",nextWeek:"dddd [à] LT",other:"L"};e.exports=d.default}});
//# sourceMappingURL=ad392012e7e738c2f2a5.js.map
