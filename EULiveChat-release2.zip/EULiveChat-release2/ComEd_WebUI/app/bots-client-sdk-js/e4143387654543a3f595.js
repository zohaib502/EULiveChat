webpackJsonp([173],{793:function(e,t,d){"use strict";function a(e,t,d,a){return o[e]}Object.defineProperty(t,"__esModule",{value:!0}),t.default=a;var o={lastWeek:"[pasinta] dddd [je] LT",yesterday:"[hieraŭ je] LT",today:"[hodiaŭ je] LT",tomorrow:"[morgaŭ je] LT",nextWeek:"dddd [je] LT",other:"L"};e.exports=t.default}});
//# sourceMappingURL=e4143387654543a3f595.js.map
