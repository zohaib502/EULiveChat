webpackJsonp([191],{775:function(e,M,Y){"use strict";Object.defineProperty(M,"__esModule",{value:!0});var d=Y(206),t=function(e){return e&&e.__esModule?e:{default:e}}(d),L=(0,t.default)({LT:"HH:mm",LTS:"HH:mm:ss",L:"DD/MM/YYYY",LL:"D. MMMM YYYY",LLL:"D. MMMM YYYY HH:mm",LLLL:"dddd [d.] D. MMMM YYYY [kl.] HH:mm"});M.default=L,e.exports=M.default}});
//# sourceMappingURL=710f99b5952e12b71924.js.map
