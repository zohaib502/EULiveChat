config = {
  "mcsHostname" : "d-e-euweb-livechat-comed-ui-01.azurewebsites.net",
  "oracleMobileBackendId" : "09282f50-ed11-4d68-b5cb-20bbed263373"
}