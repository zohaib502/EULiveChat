module.exports = {
    components: [
        './components'
    ]
};